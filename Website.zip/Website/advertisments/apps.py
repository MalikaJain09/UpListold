from django.apps import AppConfig


class AdvertismentsConfig(AppConfig):
    name = 'advertisments'
